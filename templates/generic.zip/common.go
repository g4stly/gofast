package common

import (
	"os"
	"io"
	"fmt"
	"flag"
	"net/http"
)

func init() {
	flag.Parse()
}

var silent	= flag.Bool("s", false, "silent: surpress all output")
var verbose	= flag.Bool("v", false, "verbose: print extra debug output")

/*
 * types
 */
type Context struct {

}

type IPage interface {
	Name()	string
	Serve(http.ResponseWriter, Context)
}

type IController interface {
	Execute(w http.ResponseWriter, r *http.Request)
}

/*
 * misc stuffs
 */
func AssertMethod(w http.ResponseWriter, r *http.Request, method string) bool {
	if r.Method != method {
		http.Error(w, "400 Bad Request", http.StatusBadRequest)
		return false
	}
	return true;
}

/*
 * logging stuffs
 */
func msg(w io.Writer, badge string, fmtstring string, args ...interface{}) {
	if *silent {
		return
	}
	if len(args) < 1 {
		w.Write([]byte(fmt.Sprintf("%v: %v\n", badge, fmtstring)))
	} else {
		w.Write([]byte(fmt.Sprintf("%v: %v\n", badge, fmt.Sprintf(fmtstring, args...))))
	}
}

func Log(fmtstring string, args ...interface{}) {
	if !*verbose {
		return
	}
	msg(os.Stdout, "DEBUG", fmtstring, args...)
}

func Out(fmtstring string, args ...interface{}) {
	msg(os.Stdout, "info", fmtstring, args...)
}

func Usage(fmtstring string, args ...interface{}) {
	msg(os.Stdout, "usage", fmtstring, args...)
}

func Fatal(fmtstring string, args ...interface{}) {
	msg(os.Stderr, "FATAL", fmtstring, args...)
	os.Exit(1)
}
