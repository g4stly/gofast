package routes

import (
	"fmt"
	"net/http"
	"{{.Namespace}}/{{.Name}}/common"
)

var routeList []Route
type Route struct {
	Path		string
	Controller	common.IController
}

type simpleController struct {
	page	common.IPage
}

func (self *simpleController) Execute(w http.ResponseWriter, r *http.Request) {
	if !common.AssertMethod(w, r, "GET") { return }
	self.page.Serve(w, common.Context{})
}


/*
 * exported functions below
 */
func Add(path string, ctrlr common.IController) {
	routeList = append(routeList, Route{Path: path, Controller: ctrlr})
}

func AddPageToPath(path string, page common.IPage) {
	ctrlr := &simpleController{ page: page }
	Add(path, ctrlr)
}

func AddPage(page common.IPage) {
	path := fmt.Sprintf("/%v", page.Name())
	AddPageToPath(path, page)
}

func ListenOn(portNumber int) error {
	address := fmt.Sprintf(":%v", portNumber)
	for _, route := range routeList {
		http.HandleFunc(route.Path, route.Controller.Execute)
	}
	return http.ListenAndServe(address, nil)
}
