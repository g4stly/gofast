package main

import (
	"{{.Namespace}}/{{.Name}}/routes"	// mvc model as a whole
	"{{.Namespace}}/{{.Name}}/pages"	// the view in mvc
)

func main() {

	 /*
	  * routes have controllers and paths
	  * controllers have atleast one page
	  * pages have a template and a name
	  */

	page := pages.New("index")
	routes.AddPageToPath("/", page)		// uses default controller
	routes.ListenOn({{.DefaultPort}})
}
