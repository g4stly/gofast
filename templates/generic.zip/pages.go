package pages

import (
	"fmt"
	"net/http"
	"html/template"
	"{{.Namespace}}/{{.Name}}/common"
)

var templates *template.Template

func init() {
	pattern := "templates/*.html"
	templates = template.Must(template.ParseGlob(pattern))
}

/*
 * types
 */
type Page struct {
	name		string
	template	*template.Template
}


func (self *Page) Name() string {
	return self.name
}

func (self *Page) Serve(w http.ResponseWriter, context common.Context) {
	err := self.template.Execute(w, context)
	if err != nil {
		common.Log("page %v failed to execute: %v", self.name, err)
	}
}

/*
 * exported functions
 */
func New(name string) *Page {
	newPage := &Page{name: name}
	templateName := fmt.Sprintf("%v.html", name)
	newPage.template = templates.Lookup(templateName)
	return newPage
}
